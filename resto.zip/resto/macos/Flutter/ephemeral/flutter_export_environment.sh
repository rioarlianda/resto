#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/bulanarlianda/Documents/development/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/bulanarlianda/Documents/RPL/resto/resto"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=/Users/bulanarlianda/Documents/RPL/resto/resto/lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=0.1.0"
export "FLUTTER_BUILD_NUMBER=0.1.0"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=/Users/bulanarlianda/Documents/RPL/resto/resto/.dart_tool/package_config.json"
