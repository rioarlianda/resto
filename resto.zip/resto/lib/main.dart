import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(MainApp());
}

class MainApp extends StatelessWidget {
    final biodata = <String, String>{};

  MainApp({super.key}) {
    biodata['name'] = 'RM Sedap Rasa';
    biodata['email'] = '111202012796@mhs.dinus.ac.id';
    biodata['phone'] = '+62895379127033';
    biodata['image'] = 'sedaprasa.jpeg';
    biodata['maps'] = 'maps.app.goo.gl/GTN1ydCdWNjy4APF9';
    biodata['hobby'] = 'Bermain Lira dan Flute';
    biodata['addr'] = 'Jalan Jendral Sudirman, Purwakarta';
    biodata['jambuka'] = '\u2022 Setiap Hari, Pukul 09:30 - 21:00';
    biodata['desc'] =
        "Rumah makan ini mengusung konsep chinese food atau masakan China. Rumah makan ini bernama RM Sedap Rasa.";
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "RM Sedap Rasa",
      home: Scaffold(
        appBar: AppBar(title: Text("RM Sedap Rasa")),
        body: SingleChildScrollView(
          padding: EdgeInsets.all(10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                padding: EdgeInsets.all(10),
                alignment: Alignment.center,
                width: double.infinity,

                decoration: BoxDecoration(color: Colors.black),
                child: Text(
                  biodata['name'] ?? '',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: Colors.white,
                  ),
                ),
              ),
              Image(image: AssetImage('assets/${biodata["image"] ?? ''}')),
              SizedBox(height :10),
              Row(
                children: [
                  btnContact(Icons.mark_email_read, Colors.green[900],
                    "mailto:${biodata['email'] ?? ''}"),
                  btnContact(
                    Icons.phone, Colors.deepPurple, "tel:${biodata['phone']}"),   
                  btnContact(Icons.map, Colors.blueAccent,
                    "https://${biodata['maps']}")          
                  ],
                ),
                SizedBox(height: 10),
                teksKotak(Colors.black38, 'Deskripsi'),
                SizedBox(height: 10,),
                Text(biodata['desc'] ?? '', 
                style: TextStyle(fontSize: 18
                ),
                textAlign: TextAlign.center,
                ),
                SizedBox(height: 10,),
                teksKotak(Colors.black38, 'List Menu'),
                Text('\u2022 Fuyunghai', style: TextStyle(fontSize: 18),textAlign: TextAlign.left,),
                Text('\u2022 Capjay', style: TextStyle(fontSize: 18),textAlign: TextAlign.left,),
                Text('\u2022 Bakmi Goreng', style: TextStyle(fontSize: 18),textAlign: TextAlign.left,),
                SizedBox(height: 10,),
                teksKotak(Colors.black38, 'Alamat'),
                Text(biodata['addr'] ?? '', 
                style: TextStyle(fontSize: 18
                ),
                textAlign: TextAlign.center,
                ),
                SizedBox(height: 10,),
                teksKotak(Colors.black38, 'Jam Buka'),
                Text(biodata['jambuka'] ?? '', 
                style: TextStyle(fontSize: 18
                ),
                textAlign: TextAlign.center,
                ),

            ],),
        ),
      ),
    );
  }

  Container teksKotak(Color bgColor, String teks) {
    return Container(
      padding: EdgeInsets.all(10),
      alignment: Alignment.center,
      width: double.infinity,
      decoration: BoxDecoration(color: bgColor),
      child: Text(
        teks,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 20,
          color: Colors.white,
        ),
      ),
    );
  }

  Row textAttribute(String judul, String teks) {
    return Row(
      children: [
        Container(
          width: 80,
          child: Text(
            '- $judul ',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
          ),
        ),
        Text(
          ': ',
          style: TextStyle(fontSize: 18),
        ),
        Text(
          teks,
          style: TextStyle(fontSize: 18),
        ),
      ],
    );
  }

  Expanded btnContact(IconData icon, var color, String uri) {
    return Expanded(
      child: ElevatedButton(
        onPressed: () {
          launch(uri);
        },
        child: Icon(icon),
        style: ElevatedButton.styleFrom(
            shape: StadiumBorder(),
            backgroundColor: color,
            foregroundColor: Colors.white),
      ),
    );
  }
  Future launch(String uri) async {
    if (!await launchUrl(Uri.parse(uri))) {
      throw Exception('Tidak dapat memanggil : $uri');
    }
  }

  

}

